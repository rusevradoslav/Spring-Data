package com.example.spring_data_intro_exercise.entities.enums;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
