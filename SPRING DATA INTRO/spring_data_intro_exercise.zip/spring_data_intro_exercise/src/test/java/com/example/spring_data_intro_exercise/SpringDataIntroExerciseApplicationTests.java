package com.example.spring_data_intro_exercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataIntroExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
