package com.example.game_store.domain.enums;

public enum Role {
    ADMIN ,USER
}
