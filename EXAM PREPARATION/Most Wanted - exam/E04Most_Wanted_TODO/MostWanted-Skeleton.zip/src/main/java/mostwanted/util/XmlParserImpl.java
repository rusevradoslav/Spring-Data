package mostwanted.util;

import javax.xml.bind.JAXBException;

public class XmlParserImpl implements XmlParser {

    @Override
    public <O> O parseXml(Class<O> objectClass, String filePath) throws JAXBException {
        //TODO: Implement me
        return null;
    }
}
