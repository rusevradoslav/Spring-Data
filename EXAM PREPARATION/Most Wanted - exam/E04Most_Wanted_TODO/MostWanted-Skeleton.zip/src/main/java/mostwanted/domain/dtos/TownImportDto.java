package mostwanted.domain.dtos;

public class TownImportDto {
    //TODO: Implement me
}
