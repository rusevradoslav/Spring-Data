package mostwanted.util;

public interface ValidationUtil {

    <E> boolean isValid(E entity);
}
