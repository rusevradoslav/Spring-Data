package mostwanted.domain.dtos;

public class CarImportDto {
    //TODO: Implement me
}
