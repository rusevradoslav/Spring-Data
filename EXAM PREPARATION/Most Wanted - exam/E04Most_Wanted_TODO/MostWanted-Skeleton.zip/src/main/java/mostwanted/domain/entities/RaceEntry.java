package mostwanted.domain.entities;

public class RaceEntry extends BaseEntity{
    //TODO: Implement me
}
