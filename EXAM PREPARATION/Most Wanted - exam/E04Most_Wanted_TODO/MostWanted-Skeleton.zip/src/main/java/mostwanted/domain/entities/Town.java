package mostwanted.domain.entities;

public class Town extends BaseEntity{
    //TODO: Implement me
}
