package mostwanted.domain.entities;

public class Racer extends BaseEntity{
    //TODO: Implement me
}
