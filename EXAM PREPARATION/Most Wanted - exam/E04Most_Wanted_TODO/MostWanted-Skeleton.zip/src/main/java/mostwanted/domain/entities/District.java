package mostwanted.domain.entities;

public class District  extends  BaseEntity{
    //TODO: Implement me
}
