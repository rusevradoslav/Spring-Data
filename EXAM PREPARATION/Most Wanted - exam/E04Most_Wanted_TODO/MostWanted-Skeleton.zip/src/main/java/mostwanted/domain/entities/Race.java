package mostwanted.domain.entities;

public class Race extends BaseEntity{
    //TODO: Implement me
}
