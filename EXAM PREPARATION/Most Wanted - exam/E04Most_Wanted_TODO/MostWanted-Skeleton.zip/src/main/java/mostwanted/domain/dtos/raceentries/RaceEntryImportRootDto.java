package mostwanted.domain.dtos.raceentries;

public class RaceEntryImportRootDto {
    //TODO: Implement me
}