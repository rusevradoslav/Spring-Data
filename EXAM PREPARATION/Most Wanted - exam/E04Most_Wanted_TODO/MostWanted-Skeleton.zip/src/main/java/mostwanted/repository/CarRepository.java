package mostwanted.repository;

public interface CarRepository {
    //TODO: Implement me
}
