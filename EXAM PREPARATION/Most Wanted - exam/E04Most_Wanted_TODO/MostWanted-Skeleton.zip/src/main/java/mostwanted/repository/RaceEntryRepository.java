package mostwanted.repository;

public interface RaceEntryRepository  {
    //TODO: Implement me
}
