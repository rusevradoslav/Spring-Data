package mostwanted.repository;

public interface TownRepository {
    //TODO: Implement me
}
