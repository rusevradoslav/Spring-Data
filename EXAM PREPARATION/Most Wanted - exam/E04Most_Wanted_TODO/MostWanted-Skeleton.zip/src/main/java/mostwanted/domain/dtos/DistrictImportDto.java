package mostwanted.domain.dtos;

public class DistrictImportDto {
    //TODO: Implement me
}
