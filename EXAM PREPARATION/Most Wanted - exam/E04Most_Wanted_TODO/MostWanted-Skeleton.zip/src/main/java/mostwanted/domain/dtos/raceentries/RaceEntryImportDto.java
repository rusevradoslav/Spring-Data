package mostwanted.domain.dtos.raceentries;

public class RaceEntryImportDto {
    //TODO: Implement me
}
