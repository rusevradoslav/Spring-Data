package mostwanted.domain.entities;

public class Car extends BaseEntity{
    //TODO: Implement me
}
