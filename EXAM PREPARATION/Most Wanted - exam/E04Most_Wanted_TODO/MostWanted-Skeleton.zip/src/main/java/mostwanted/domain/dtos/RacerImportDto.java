package mostwanted.domain.dtos;

public class RacerImportDto {
    //TODO: Implement me

}
